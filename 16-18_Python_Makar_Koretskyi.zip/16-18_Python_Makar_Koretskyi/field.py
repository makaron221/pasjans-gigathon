from random import randint, shuffle

class Field:
    black = ('♠', '♣')
    red = ('♥', '♦')

    def __init__(self):
        self.cards, self.field, self.open, self.columns = [], [], [], []

        for i in range(1, 14):
            temp = [0 for j in range(7)]
            self.field.append(temp.copy())
            self.open.append(temp.copy())

            for j in self.red+self.black:
                self.cards.append((i, j))

            self.columns.append([0 for j in range(4)])
        
        for i in range(7):
            for j in range(i+1):
                temp = randint(0, len(self.cards)-1)
                self.field[j][i] = self.cards.pop(temp)
                if i==j: self.open[j][i]=True
            
        shuffle(self.cards)
        

    def is_on_top(self, x:int, y:int) -> bool:
        if y==13 or y==14: return True
        elif not self.field[y+1][x]: return True
        return False
    

    def move_cards(self, base:tuple, destination:tuple) -> bool:#base/destination=(x, y)
        
        if base[1] == -1:
            self.field.append([self.cards[0]])
            self.open.append([True])
            self.cards.pop(0)
            return self.move_cards((0, len(self.field)-1), destination)
        elif destination[0]>6: return self.to_final(base, destination)
        return self.to_initial(base, destination)
    
    def to_initial(self, base:tuple, destination:tuple, a=True) -> bool:
        if destination[1]==0 :
            if self.field[base[1]][base[0]][0]!=13: 
                return False
        else:
            if self.field[base[1]][base[0]][0]+1!=self.field[destination[1]-1][destination[0]][0] or \
            self.field[base[1]][base[0]][1] in self.black and self.field[destination[1]-1][destination[0]][1] in self.black\
            or self.field[base[1]][base[0]][1] in self.red and self.field[destination[1]-1][destination[0]][1] in self.red:
                return False
            
        self.field[destination[1]][destination[0]] = self.field[base[1]][base[0]]
        self.field[base[1]][base[0]] = 0

        self.open[destination[1]][destination[0]] = True
        self.open[base[1]][base[0]] = False
        if base[1]!=0 and a: self.open[base[1]-1][base[0]] = True

        if not self.is_on_top(*base):
            return self.to_initial((base[0], base[1]+1), (destination[0], destination[1]+1), False)

        return True

    def to_final(self, base:tuple, destination:tuple) -> bool:
        def move():
            self.columns[destination[1]][destination[0]-7] = self.field[base[1]][base[0]]
            self.field[base[1]][base[0]] = 0
            self.open[base[1]][base[0]] = False
            if base[1]!=0: self.open[base[1]-1][base[0]] = True

        if self.is_on_top(*base):
            if destination[1]==0:
                if self.field[base[1]][base[0]][0]==1:
                    move()
                    return True
            else:
                if self.field[base[1]][base[0]][0]==self.columns[destination[1]-1][destination[0]-7][0]+1 and\
                self.field[base[1]][base[0]][1]==self.columns[0][destination[0]-7][1]:
                    move()
                    return True
        return False