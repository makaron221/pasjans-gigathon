from game import Game

def main():
    g = Game()

    while True:
        g.show()
        g.win_condition()
        g.move()

if __name__ == "__main__":
    main()