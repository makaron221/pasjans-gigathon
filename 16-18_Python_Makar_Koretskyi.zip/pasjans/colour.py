font_codes = {"black":"30", "red":"31", "green":"32", "white":"97", "blue":"34"}
bg_codes = {"white":"47", "black":"40", "green":"102", "red":"41"}
reset = "\033[0m"
set_bg = lambda colour: "\033["+bg_codes.get(colour, "0")+"m"
set_font = lambda colour: "\033["+font_codes.get(colour, "0")+"m"