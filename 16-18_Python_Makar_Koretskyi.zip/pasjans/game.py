import colour
from field import Field
from os import system, name as os_name
from keyboard import is_pressed 
from copy import deepcopy
from random import shuffle

class Save:
    def __init__(self, **attr):
        for key, value in tuple(attr.items()):
            setattr(self, key, value)

    def __repr__(self):
        return str(tuple(self.__dict__.items()))
    


class Game(Field):

    def __init__(self):
        self.difficulty = self.get_difficulty()
        self.saves = []
        super().__init__()
        self.cursor = [[0, 0, 0], [0, 0, 0]]#x, y, status
        self.shown_cards = []
        self.counter = 0
        self.add_save()

    def get_colour(self, a:str) -> str:
        if a in self.red:
            return "red"
        return "green"


    def asm_card(self, x:int, y:int) -> str:
        letters = {1:"A", 11:"J", 12:"Q", 13:"K"}
        if y==-1:
            if x==0:
                a="[*]"
            else:
                if len(self.cards)<x:
                    a=""
                else:
                    card = self.cards[x-1]
                    c = self.get_colour(card[1])
                    a = str(letters.get(card[0], card[0]))+colour.set_font(c)+card[1]+colour.reset
        elif x<7:
           if self.open[y][x]:
                try:#################################
                    c = self.get_colour(self.field[y][x][1])
                    a = str(letters.get(self.field[y][x][0], self.field[y][x][0]))+colour.set_font(c)+self.field[y][x][1]+colour.reset
                except: ##############################
                    a=""
                    self.open[y][x] = False
           else:
               if self.field[y][x]:
                   a = "[]"
               else:
                   a = ""
        else:
            a =x-7
            if self.columns[y][a]:
                c = self.get_colour(self.columns[y][a][1])
                a = str(letters.get(self.columns[y][a][0], self.columns[y][a][0]))+colour.set_font(c)+self.columns[y][a][1]+colour.reset
            else:
                a = ""
        
        if self.cursor[0][0]==x and self.cursor[0][1]==y:
            if not a:
                a = "  "
            c = colour.set_bg("red") if self.cursor[0][2] else colour.set_bg("green")
            a = c+a+colour.reset
        elif self.cursor[1][0]==x and self.cursor[1][1]==y and self.cursor[0][2]:
            if not a:
                a = "  "
            a = colour.set_bg("green")+a+colour.reset
        return a
        
    def show(self) -> None:

        system("cls" if os_name=="nt" else "clear")

        for i in range(11):print("*", end="\t")
        print("")
        
        for i in range(self.difficulty+1):
            print(self.asm_card(i, -1), end="  ")
        print("")

        for i in range(13):
            for j in range(11):
                print(self.asm_card(j, i), end="\t") 
            print("")
        print("")

        for i in range(11):print("*", end="\t")

    def move(self) -> None:
        while True:
            self.exit()

            if (is_pressed("a") or is_pressed("left")) :
                while is_pressed("a") or is_pressed("left"): pass
                if self.cursor[0][0]!=0 and not self.cursor[0][2]:
                    self.cursor[0][0] -= 1
                elif self.cursor[1][0]!=0 and self.cursor[0][2]:
                    self.cursor[1][0] -= 1
                break

            elif (is_pressed("d") or is_pressed("right")):
                while is_pressed("d") or is_pressed("right"): pass
                if self.cursor[0][1] == -1 and self.cursor[0][0] != 1:
                    self.cursor[0][0] += 1
                elif self.cursor[0][0]!=10 and not self.cursor[0][2] and self.cursor[0][1]!=-1:
                    self.cursor[0][0] += 1
                elif self.cursor[1][0]!=10 and self.cursor[0][2]:
                    self.cursor[1][0] += 1
                break

            elif (is_pressed("w") or is_pressed("up")):
                while is_pressed("w") or is_pressed("up"): pass
                if self.cursor[0][1]==0 and not self.cursor[0][2]:
                    self.cursor[0][0] = 0
                    self.cursor[0][1] = -1
                elif self.cursor[1][1]==0 and self.cursor[0][2]:
                    self.cursor[1][0] = 0
                    self.cursor[1][1] = -1
                elif self.cursor[0][1]>0 and not self.cursor[0][2]:
                    self.cursor[0][1] -= 1
                elif self.cursor[1][1]!=0 and self.cursor[0][2]:
                    self.cursor[1][1] -= 1 
                break

            elif (is_pressed("s") or is_pressed("down")):
                while (is_pressed("s") or is_pressed("down")): pass
                if self.cursor[0][1]!=12 and not self.cursor[0][2]:
                    self.cursor[0][1] += 1
                elif self.cursor[1][1]!=12 and self.cursor[0][2]:
                    self.cursor[1][1] += 1
                break

            elif is_pressed('q'):
                while is_pressed('q'): pass
                self.load_last_save()
                self.show()

            elif is_pressed("space"):
                while is_pressed("space"): pass
                if self.cursor[0][0] == 0 and self.cursor[0][1] == -1:
                    if len(self.cards) < 2:
                        return
                    self.counter += 1
                    for i in range(self.difficulty):
                        card = self.cards.pop(0)
                        self.cards.append(card)
                        if self.cards[1] in self.shown_cards:
                            shuffle(self.cards)
                            self.shown_cards = []
                        else:
                            self.shown_cards.append(card)
                    self.add_save()

                elif self.cursor[0][0:2]==self.cursor[1][0:2] and self.cursor[0][2]:
                    self.cursor[0][2] = False

                elif self.cursor[0][2]==True and self.cursor[1][0]<=6 and self.cursor[1][1]==0:
                    self.cursor[1][2]=True

                elif not self.cursor[0][2] and (self.open[self.cursor[0][1]][self.cursor[0][0]] or (self.cursor[0][0]==1 and self.cursor[0][1]==-1)):
                    self.cursor[0][2] = True
                    self.cursor[1][0] = self.cursor[0][0]
                    self.cursor[1][1] = self.cursor[0][1]

                elif self.cursor[0][2]:
                    try:
                        if self.cursor[1][0]>6:
                            a = bool(self.columns[self.cursor[1][1]-1][self.cursor[1][0]])
                        else:
                            a = self.open[self.cursor[1][1]-1][self.cursor[1][0]]
                    except IndexError:
                        a = True
                    if a:
                        self.cursor[1][2] = True                        
                break
        
        if self.cursor[0][2] and self.cursor[1][2]:
            a = self.move_cards(self.cursor[0][0:2], self.cursor[1][0:2])
            self.cursor[1][2] = False
            if a:
                self.cursor[0] = self.cursor[1].copy()
                self.counter += 1
                self.add_save()

    def get_difficulty(self) -> int:#1-latwy, 3-trudny
        switch = False
        while True:
            system("cls" if os_name=="nt" else "clear")
            print("Wybierz poziom trudności\n")
            for text, index in (("Łatwy", 0), ("Trudny", 1)):
                if switch == index:
                    text = colour.set_bg("green")+" "+text+" "+colour.reset
                text = "\t"+text
                print(text)

            while True:
                if is_pressed("up") or is_pressed("down"):
                    switch = not switch
                    while is_pressed("up") or is_pressed("down"): pass
                    break
                elif is_pressed("space"):
                    while is_pressed("space"): pass
                    if switch:
                        return 3
                    else:
                        return 1
      
    def add_save(self) -> None:
        attr = list(self.__dict__.items())
        attr.pop(1)#usuwa atrybut save, nalezy zmienic przy dodaniu nowych atrybutow
        attr = dict(map(lambda x: (x[0], deepcopy(x[1])), attr))
        save = Save(**attr)
        self.saves.append(save)
        if len(self.saves) > 4:
            self.saves.pop(0)

    def load_last_save(self) -> None:
        if len(self.saves) == 1: return
        self.saves.pop(-1)
        save = deepcopy(self.saves[-1])
        for key, value in list(save.__dict__.items()):
            self.__dict__[key] = value
        
    def exit(self) -> None:
        if is_pressed("e"):
            raise SystemExit
        elif is_pressed("r"):
            self.__init__()

    def win_condition(self) -> None:
        for i in range(4):
            if not self.columns[-1][i]: return
        with open("ranking.txt", "a") as file:
            file.write(str(self.counter)+"\n")
        with open("ranking.txt") as file:
                ranking = sorted(list(map(int, file.read().split("\n")[0:-1])))

        print(f"\nWygrałeś/aś\nLiczba twych ruchów wyniosła {self.counter}")
        print("Najlepsze wyniki to:")
        for i in range(len(ranking) if len(ranking)<5 else 5):
            print(f"{i+1}. {ranking[i]}")
        raise SystemExit